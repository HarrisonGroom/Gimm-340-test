module.exports = [
  'parking will cost three dollars and seventy five an hour',
  'parking is free today',
  'parking will range from free to 2 dollars depending upon spaces'
];